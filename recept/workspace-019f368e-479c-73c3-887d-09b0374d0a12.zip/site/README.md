# Mitt Maskinkök 🍳

Databas över mina matlagningsmaskiner och recept, med programförslag för varje rätt.

## Publicera gratis på GitHub Pages

1. Skapa konto på [github.com](https://github.com)
2. Skapa nytt repository (t.ex. `maskinkok`), välj **Public**
3. Ladda upp ALLA filer i denna mapp (behåll mappstrukturen: `recept/`, `images/`)
4. **Settings → Pages → Source: Deploy from branch → main → / (root)** → Save
5. Efter ~1 minut: `https://DITTNAMN.github.io/maskinkok/`

## Lägga till ny maskin (automatiskt!)

1. Kopiera en fil i `json/maskiner/`, ändra innehållet (se MALL-ny-maskin.json.txt)
2. Ladda upp till `json/maskiner/` — klart, läses in automatiskt!

## Lägga till nytt recept (automatiskt!)

1. Kopiera `recept/ananaskaka.html`, döp om (t.ex. `kottgryta.html`)
2. Ändra metadata-taggarna i `<head>` (namn, emoji, beskrivning, taggar, maskiner)
3. Ändra innehållet
4. Ladda upp till `recept/`-mappen — **klart! Startsidan hittar den automatiskt** (via GitHub API)
5. Egen bild? Lägg `images/recept/kottgryta.jpg` (samma namn som receptet) — visas automatiskt överst på receptet och som miniatyr på startsidan

## Filstruktur

- `index.html` – startsida: receptsök, maskinväljare, maskingalleri
- `maskindatabas.html` – interaktiv maskindatabas med programförslag
- `json/maskindatabas.json` – basdata (recept-register, AI-instruktion)
- `json/maskiner/` – EN fil per maskin (alla .json läses in automatiskt!)
- `json/maskiner-index.json`, `json/recept-index.json` – reservlistor (behövs bara utanför GitHub Pages)
- `recept/` – receptkort (alla .html läses in automatiskt)
- `images/` – maskinbilder
- `images/recept/` – receptbilder (samma filnamn som receptet)

## Funktioner

- 🔍 Sök bland recept
- 🔧 Filtrera recept per maskin
- ⭐ Betygsätt recept + egna anteckningar (sparas i webbläsaren)
- 🖨️ Utskriftsvänligt läge på receptkorten
- 📱 QR-kod på varje recept – skriv ut och skanna i köket
